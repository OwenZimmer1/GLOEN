import React from 'react';

const PocketHazmapp: React.FC = () => {
  return (
    <div>
      <h1> Pocket Hazmapp Coming Soon.... </h1>
    </div>
  );
};

export default PocketHazmapp;
